Mandatory assignment 1

I have cooperated with Saurav Sharma (sauravsh) in this assignment.

To run:
	- Compile BinSearchTree.java, FileReader.java, SimilarWords.java and UserInteraction.java
	- Run UserInteraction.class (with the dictionary-filename as a command-line argument)
	